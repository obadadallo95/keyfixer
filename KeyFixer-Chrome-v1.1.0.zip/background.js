// src/core/keyboard/layouts/windowsArabic101.ts
function createReverseMap(enMap) {
  const map = {};
  for (const [enKey, arKey] of Object.entries(enMap)) {
    if (!map[arKey]) {
      map[arKey] = enKey;
    }
  }
  map["\u0644\u0627"] = "b";
  map["\u0644\u0623"] = "G";
  map["\u0644\u0625"] = "T";
  map["\u0644\u0622"] = "B";
  return map;
}
var WIN_EN_TO_AR_MAP = {
  "`": "\u0630",
  "1": "\u0661",
  "2": "\u0662",
  "3": "\u0663",
  "4": "\u0664",
  "5": "\u0665",
  "6": "\u0666",
  "7": "\u0667",
  "8": "\u0668",
  "9": "\u0669",
  "0": "\u0660",
  "-": "-",
  "=": "=",
  "q": "\u0636",
  "w": "\u0635",
  "e": "\u062B",
  "r": "\u0642",
  "t": "\u0641",
  "y": "\u063A",
  "u": "\u0639",
  "i": "\u0647",
  "o": "\u062E",
  "p": "\u062D",
  "[": "\u062C",
  "]": "\u062F",
  "\\": "\\",
  "a": "\u0634",
  "s": "\u0633",
  "d": "\u064A",
  "f": "\u0628",
  "g": "\u0644",
  "h": "\u0627",
  "j": "\u062A",
  "k": "\u0646",
  "l": "\u0645",
  ";": "\u0643",
  "'": "\u0637",
  "z": "\u0626",
  "x": "\u0621",
  "c": "\u0624",
  "v": "\u0631",
  "b": "\u0644\u0627",
  "n": "\u0649",
  "m": "\u0629",
  ",": "\u0648",
  ".": "\u0632",
  "/": "\u0638",
  "~": "\u0651",
  "!": "!",
  "@": "@",
  "#": "#",
  "$": "$",
  "%": "%",
  "^": "^",
  "&": "&",
  "*": "*",
  "(": ")",
  ")": "(",
  "_": "_",
  "+": "+",
  "Q": "\u064E",
  "W": "\u064B",
  "E": "\u064F",
  "R": "\u064C",
  "T": "\u0644\u0625",
  "Y": "\u0625",
  "U": "\u2018",
  "I": "\xF7",
  "O": "\xD7",
  "P": "\u061B",
  "{": "<",
  "}": ">",
  "|": "|",
  "A": "\u0650",
  "S": "\u064D",
  "D": "]",
  "F": "[",
  "G": "\u0644\u0623",
  "H": "\u0623",
  "J": "\u0640",
  "K": "\u060C",
  "L": "/",
  ":": ":",
  '"': '"',
  "Z": "~",
  "X": "\u0652",
  "C": "}",
  "V": "{",
  "B": "\u0644\u0622",
  "N": "\u0622",
  "M": "\u2019",
  "<": ",",
  ">": ".",
  "?": "\u061F"
};
var WIN_AR_TO_EN_MAP = createReverseMap(WIN_EN_TO_AR_MAP);

// src/core/keyboard/layouts/macArabic.ts
function createReverseMap2(enMap) {
  const map = {};
  for (const [enKey, arKey] of Object.entries(enMap)) {
    if (!map[arKey]) {
      map[arKey] = enKey;
    }
  }
  map["\u0644\u0627"] = "b";
  map["\u0644\u0623"] = "G";
  map["\u0644\u0625"] = "T";
  map["\u0644\u0622"] = "B";
  return map;
}
var MAC_EN_TO_AR_MAP = {
  ...WIN_EN_TO_AR_MAP,
  "`": "\xA7",
  "[": "\u062C",
  "]": "\u0629",
  "'": "\u061B",
  "\\": "\\",
  "z": "\u0638",
  "x": "\u0637",
  "c": "\u0630",
  "v": "\u062F",
  "b": "\u0632",
  "n": "\u0631",
  "m": "\u0648",
  ",": "\u060C",
  ".": ".",
  "/": "/",
  "~": "\xB1",
  "Z": "\u0638",
  "X": "\u0637",
  "C": "\u0626",
  "V": "\u0621",
  "B": "\u0623",
  "N": "\u0625",
  "M": "\u0624",
  "<": ">",
  ">": "<",
  "?": "\u061F"
};
var MAC_AR_TO_EN_MAP = createReverseMap2(MAC_EN_TO_AR_MAP);

// src/core/keyboard/detectConversionDirection.ts
function detectMistypedMode(text, platform = "windows") {
  if (!text || text.trim().length === 0) return "en2ar";
  const en2ar = platform === "mac" ? MAC_EN_TO_AR_MAP : WIN_EN_TO_AR_MAP;
  let enCount = 0;
  let arCount = 0;
  for (const char of text) {
    if (en2ar[char] && /[a-zA-Z;':,.\/\[\]\\`~]/.test(char)) {
      enCount++;
    } else if (/[\u0600-\u06FF]/.test(char)) {
      arCount++;
    }
  }
  return enCount >= arCount ? "en2ar" : "ar2en";
}

// src/core/keyboard/keyboardLayoutConverter.ts
function getKeyMaps(platform = "windows") {
  if (platform === "mac") {
    return { en2ar: MAC_EN_TO_AR_MAP, ar2en: MAC_AR_TO_EN_MAP };
  }
  return { en2ar: WIN_EN_TO_AR_MAP, ar2en: WIN_AR_TO_EN_MAP };
}
function convertKeyboardLayout(text, options = {}) {
  const { mode = "auto", platform = "windows" } = options;
  if (!text) {
    return {
      originalText: "",
      fixedText: "",
      appliedMode: "en2ar",
      platform,
      charCount: 0,
      wordCount: 0,
      changedCharCount: 0
    };
  }
  const { en2ar, ar2en } = getKeyMaps(platform);
  const appliedMode = mode === "auto" ? detectMistypedMode(text, platform) : mode;
  const mapping = appliedMode === "en2ar" ? en2ar : ar2en;
  let fixedText = "";
  let changedCharCount = 0;
  let i = 0;
  while (i < text.length) {
    if (appliedMode === "ar2en") {
      const doubleChar = text.substring(i, i + 2);
      if (mapping[doubleChar]) {
        fixedText += mapping[doubleChar];
        changedCharCount += 2;
        i += 2;
        continue;
      }
    }
    const char = text[i];
    if (mapping[char] !== void 0) {
      fixedText += mapping[char];
      if (mapping[char] !== char) {
        changedCharCount++;
      }
    } else {
      fixedText += char;
    }
    i++;
  }
  const words = text.trim().split(/\s+/).filter(Boolean);
  return {
    originalText: text,
    fixedText,
    appliedMode,
    platform,
    charCount: text.length,
    wordCount: words.length,
    changedCharCount
  };
}

// extension/src/background.ts
var menuLabels = {
  en: {
    replace: "Fix selected text with KeyFixer",
    copy: "Fix and copy corrected text"
  },
  ar: {
    replace: "\u062A\u0635\u062D\u064A\u062D \u0627\u0644\u0646\u0635 \u0627\u0644\u0645\u062D\u062F\u062F \u0628\u0627\u0633\u062A\u062E\u062F\u0627\u0645 KeyFixer",
    copy: "\u062A\u0635\u062D\u064A\u062D \u0627\u0644\u0646\u0635 \u0648\u0646\u0633\u062E \u0627\u0644\u0646\u062A\u064A\u062C\u0629"
  }
};
chrome.runtime.onInstalled.addListener(() => void registerContextMenus());
chrome.runtime.onStartup.addListener(() => void registerContextMenus());
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.uiLanguage) void registerContextMenus();
});
async function getLanguage() {
  const result = await chrome.storage.local.get("uiLanguage");
  if (result.uiLanguage === "ar" || result.uiLanguage === "en") return result.uiLanguage;
  return chrome.i18n.getUILanguage().toLowerCase().startsWith("ar") ? "ar" : "en";
}
async function registerContextMenus() {
  const language = await getLanguage();
  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({
    id: "keyfixer-convert",
    title: menuLabels[language].replace,
    contexts: ["selection"]
  });
  chrome.contextMenus.create({
    id: "keyfixer-copy-fixed",
    title: menuLabels[language].copy,
    contexts: ["selection"]
  });
}
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!info.selectionText || !tab?.id) return;
  const storageResult = await chrome.storage.local.get(["platform", "mode"]);
  const platform = storageResult.platform || "windows";
  const mode = storageResult.mode || "auto";
  const result = convertKeyboardLayout(info.selectionText, { mode, platform });
  const action = info.menuItemId === "keyfixer-convert" ? "replaceText" : "copyText";
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
    await chrome.tabs.sendMessage(tab.id, {
      action,
      original: info.selectionText,
      fixed: result.fixedText
    });
  } catch (error) {
    console.warn("KeyFixer: This browser page does not allow extension scripts.", error);
  }
});

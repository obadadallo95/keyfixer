// src/core/keyboard/layouts/windowsArabic101.ts
function createReverseMap(enMap) {
  const map = {};
  for (const [enKey, arKey] of Object.entries(enMap)) {
    if (!map[arKey]) {
      map[arKey] = enKey;
    }
  }
  map["\u0644\u0627"] = "b";
  map["\u0644\u0623"] = "G";
  map["\u0644\u0625"] = "T";
  map["\u0644\u0622"] = "B";
  return map;
}
var WIN_EN_TO_AR_MAP = {
  "`": "\u0630",
  "1": "\u0661",
  "2": "\u0662",
  "3": "\u0663",
  "4": "\u0664",
  "5": "\u0665",
  "6": "\u0666",
  "7": "\u0667",
  "8": "\u0668",
  "9": "\u0669",
  "0": "\u0660",
  "-": "-",
  "=": "=",
  "q": "\u0636",
  "w": "\u0635",
  "e": "\u062B",
  "r": "\u0642",
  "t": "\u0641",
  "y": "\u063A",
  "u": "\u0639",
  "i": "\u0647",
  "o": "\u062E",
  "p": "\u062D",
  "[": "\u062C",
  "]": "\u062F",
  "\\": "\\",
  "a": "\u0634",
  "s": "\u0633",
  "d": "\u064A",
  "f": "\u0628",
  "g": "\u0644",
  "h": "\u0627",
  "j": "\u062A",
  "k": "\u0646",
  "l": "\u0645",
  ";": "\u0643",
  "'": "\u0637",
  "z": "\u0626",
  "x": "\u0621",
  "c": "\u0624",
  "v": "\u0631",
  "b": "\u0644\u0627",
  "n": "\u0649",
  "m": "\u0629",
  ",": "\u0648",
  ".": "\u0632",
  "/": "\u0638",
  "~": "\u0651",
  "!": "!",
  "@": "@",
  "#": "#",
  "$": "$",
  "%": "%",
  "^": "^",
  "&": "&",
  "*": "*",
  "(": ")",
  ")": "(",
  "_": "_",
  "+": "+",
  "Q": "\u064E",
  "W": "\u064B",
  "E": "\u064F",
  "R": "\u064C",
  "T": "\u0644\u0625",
  "Y": "\u0625",
  "U": "\u2018",
  "I": "\xF7",
  "O": "\xD7",
  "P": "\u061B",
  "{": "<",
  "}": ">",
  "|": "|",
  "A": "\u0650",
  "S": "\u064D",
  "D": "]",
  "F": "[",
  "G": "\u0644\u0623",
  "H": "\u0623",
  "J": "\u0640",
  "K": "\u060C",
  "L": "/",
  ":": ":",
  '"': '"',
  "Z": "~",
  "X": "\u0652",
  "C": "}",
  "V": "{",
  "B": "\u0644\u0622",
  "N": "\u0622",
  "M": "\u2019",
  "<": ",",
  ">": ".",
  "?": "\u061F"
};
var WIN_AR_TO_EN_MAP = createReverseMap(WIN_EN_TO_AR_MAP);

// src/core/keyboard/layouts/macArabic.ts
function createReverseMap2(enMap) {
  const map = {};
  for (const [enKey, arKey] of Object.entries(enMap)) {
    if (!map[arKey]) {
      map[arKey] = enKey;
    }
  }
  map["\u0644\u0627"] = "b";
  map["\u0644\u0623"] = "G";
  map["\u0644\u0625"] = "T";
  map["\u0644\u0622"] = "B";
  return map;
}
var MAC_EN_TO_AR_MAP = {
  ...WIN_EN_TO_AR_MAP,
  "`": "\xA7",
  "[": "\u062C",
  "]": "\u0629",
  "'": "\u061B",
  "\\": "\\",
  "z": "\u0638",
  "x": "\u0637",
  "c": "\u0630",
  "v": "\u062F",
  "b": "\u0632",
  "n": "\u0631",
  "m": "\u0648",
  ",": "\u060C",
  ".": ".",
  "/": "/",
  "~": "\xB1",
  "Z": "\u0638",
  "X": "\u0637",
  "C": "\u0626",
  "V": "\u0621",
  "B": "\u0623",
  "N": "\u0625",
  "M": "\u0624",
  "<": ">",
  ">": "<",
  "?": "\u061F"
};
var MAC_AR_TO_EN_MAP = createReverseMap2(MAC_EN_TO_AR_MAP);

// src/core/keyboard/detectConversionDirection.ts
function detectMistypedMode(text, platform = "windows") {
  if (!text || text.trim().length === 0) return "en2ar";
  const en2ar = platform === "mac" ? MAC_EN_TO_AR_MAP : WIN_EN_TO_AR_MAP;
  let enCount = 0;
  let arCount = 0;
  for (const char of text) {
    if (en2ar[char] && /[a-zA-Z;':,.\/\[\]\\`~]/.test(char)) {
      enCount++;
    } else if (/[\u0600-\u06FF]/.test(char)) {
      arCount++;
    }
  }
  return enCount >= arCount ? "en2ar" : "ar2en";
}

// src/core/keyboard/keyboardLayoutConverter.ts
function getKeyMaps(platform = "windows") {
  if (platform === "mac") {
    return { en2ar: MAC_EN_TO_AR_MAP, ar2en: MAC_AR_TO_EN_MAP };
  }
  return { en2ar: WIN_EN_TO_AR_MAP, ar2en: WIN_AR_TO_EN_MAP };
}
function convertKeyboardLayout(text, options = {}) {
  const { mode = "auto", platform = "windows" } = options;
  if (!text) {
    return {
      originalText: "",
      fixedText: "",
      appliedMode: "en2ar",
      platform,
      charCount: 0,
      wordCount: 0,
      changedCharCount: 0
    };
  }
  const { en2ar, ar2en } = getKeyMaps(platform);
  const appliedMode = mode === "auto" ? detectMistypedMode(text, platform) : mode;
  const mapping = appliedMode === "en2ar" ? en2ar : ar2en;
  let fixedText = "";
  let changedCharCount = 0;
  let i = 0;
  while (i < text.length) {
    if (appliedMode === "ar2en") {
      const doubleChar = text.substring(i, i + 2);
      if (mapping[doubleChar]) {
        fixedText += mapping[doubleChar];
        changedCharCount += 2;
        i += 2;
        continue;
      }
    }
    const char = text[i];
    if (mapping[char] !== void 0) {
      fixedText += mapping[char];
      if (mapping[char] !== char) {
        changedCharCount++;
      }
    } else {
      fixedText += char;
    }
    i++;
  }
  const words = text.trim().split(/\s+/).filter(Boolean);
  return {
    originalText: text,
    fixedText,
    appliedMode,
    platform,
    charCount: text.length,
    wordCount: words.length,
    changedCharCount
  };
}

// extension/src/popup.ts
var messages = {
  en: {
    tagline: "Fix keyboard layouts instantly",
    offlineBadge: "Local & private",
    directionLabel: "Conversion direction",
    keyboardLabel: "Keyboard",
    modeAuto: "Auto",
    modeEnAr: "EN \u2192 AR",
    modeArEn: "AR \u2192 EN",
    inputLabel: "Original text",
    inputPlaceholder: "Type or paste mistyped text\u2026",
    outputLabel: "Corrected text",
    outputPlaceholder: "The corrected text appears here\u2026",
    instantResult: "Instant result",
    copyButton: "Copy corrected text",
    copiedButton: "Copied",
    clearButton: "Clear",
    privacyNote: "Text is processed locally and never leaves your device.",
    privacyLink: "Privacy",
    termsLink: "Terms",
    developerLink: "Developer",
    privacyTitle: "Privacy policy",
    privacyUpdated: "Updated August 1, 2026",
    privacyCommitmentTitle: "Your text stays yours",
    privacyCommitmentBody: "KeyFixer processes text entirely on your device. It does not send text, browsing history, or personal information to any server.",
    privacyStorageTitle: "What is stored",
    privacyStorageBody: "Only your keyboard, conversion mode, and interface language preferences are stored locally. Typed and corrected text is never saved.",
    privacyPermissionsTitle: "Why permissions are needed",
    privacyPermissionContext: "Context menus: show KeyFixer when you right-click selected text.",
    privacyPermissionActive: "Active tab and scripting: run only after you choose a KeyFixer command, on that page.",
    privacyPermissionStorage: "Storage: remember preferences on this device.",
    privacyPermissionClipboard: "Clipboard: copy the corrected result when requested.",
    privacyNoServices: "The extension contains no analytics, advertising, accounts, or third-party network services.",
    termsTitle: "Terms of use",
    termsUpdated: "Updated August 1, 2026",
    termsPurposeTitle: "Purpose",
    termsPurposeBody: "KeyFixer is a free utility for correcting text typed with the wrong Arabic or English keyboard layout.",
    termsUseTitle: "Acceptable use",
    termsUseBody: "You may use it for personal or professional work. You may not use it for illegal activity, misrepresent it as your own product, or misuse its name or identity.",
    termsDisclaimerTitle: "Disclaimer",
    termsDisclaimerBody: "The extension is provided as is. Review corrected text before relying on it; compatibility and conversion accuracy cannot be guaranteed on every website or configuration.",
    developerTitle: "About the developer",
    developerName: "Obada Dallo",
    developerBody: "KeyFixer is an independent, privacy-first tool designed and developed by Obada Dallo to make Arabic and English typing faster and less frustrating.",
    contactDeveloper: "Contact the developer",
    externalNote: "Opens the official contact page in a new tab.",
    backLabel: "Back"
  },
  ar: {
    tagline: "\u0635\u062D\u0651\u062D \u062A\u062E\u0637\u064A\u0637 \u0644\u0648\u062D\u0629 \u0627\u0644\u0645\u0641\u0627\u062A\u064A\u062D \u0641\u0648\u0631\u0627\u064B",
    offlineBadge: "\u0645\u062D\u0644\u064A \u0648\u062E\u0627\u0635",
    directionLabel: "\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u062A\u062D\u0648\u064A\u0644",
    keyboardLabel: "\u0644\u0648\u062D\u0629 \u0627\u0644\u0645\u0641\u0627\u062A\u064A\u062D",
    modeAuto: "\u0643\u0634\u0641 \u062A\u0644\u0642\u0627\u0626\u064A",
    modeEnAr: "\u0625\u0646\u062C\u0644\u064A\u0632\u064A \u2190 \u0639\u0631\u0628\u064A",
    modeArEn: "\u0639\u0631\u0628\u064A \u2190 \u0625\u0646\u062C\u0644\u064A\u0632\u064A",
    inputLabel: "\u0627\u0644\u0646\u0635 \u0627\u0644\u0623\u0635\u0644\u064A",
    inputPlaceholder: "\u0627\u0643\u062A\u0628 \u0623\u0648 \u0627\u0644\u0635\u0642 \u0627\u0644\u0646\u0635 \u0627\u0644\u0645\u0643\u062A\u0648\u0628 \u0628\u0627\u0644\u062A\u062E\u0637\u064A\u0637 \u0627\u0644\u062E\u0637\u0623\u2026",
    outputLabel: "\u0627\u0644\u0646\u0635 \u0627\u0644\u0645\u0635\u062D\u062D",
    outputPlaceholder: "\u0633\u062A\u0638\u0647\u0631 \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u0645\u0635\u062D\u062D\u0629 \u0647\u0646\u0627\u2026",
    instantResult: "\u0646\u062A\u064A\u062C\u0629 \u0641\u0648\u0631\u064A\u0629",
    copyButton: "\u0646\u0633\u062E \u0627\u0644\u0646\u0635 \u0627\u0644\u0645\u0635\u062D\u062D",
    copiedButton: "\u062A\u0645 \u0627\u0644\u0646\u0633\u062E",
    clearButton: "\u0645\u0633\u062D",
    privacyNote: "\u064A\u064F\u0639\u0627\u0644\u062C \u0627\u0644\u0646\u0635 \u0645\u062D\u0644\u064A\u0627\u064B \u0648\u0644\u0627 \u064A\u063A\u0627\u062F\u0631 \u062C\u0647\u0627\u0632\u0643 \u0623\u0628\u062F\u0627\u064B.",
    privacyLink: "\u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629",
    termsLink: "\u0627\u0644\u0634\u0631\u0648\u0637",
    developerLink: "\u0627\u0644\u0645\u0637\u0648\u0631",
    privacyTitle: "\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629",
    privacyUpdated: "\u0622\u062E\u0631 \u062A\u062D\u062F\u064A\u062B: 1 \u0623\u063A\u0633\u0637\u0633 2026",
    privacyCommitmentTitle: "\u0646\u0635\u0643 \u064A\u0628\u0642\u0649 \u0644\u0643",
    privacyCommitmentBody: "\u064A\u0639\u0627\u0644\u062C KeyFixer \u0627\u0644\u0646\u0635 \u0628\u0627\u0644\u0643\u0627\u0645\u0644 \u0639\u0644\u0649 \u062C\u0647\u0627\u0632\u0643. \u0644\u0627 \u064A\u0631\u0633\u0644 \u0627\u0644\u0646\u0635\u0648\u0635 \u0623\u0648 \u0633\u062C\u0644 \u0627\u0644\u062A\u0635\u0641\u062D \u0623\u0648 \u0623\u064A \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0634\u062E\u0635\u064A\u0629 \u0625\u0644\u0649 \u0623\u064A \u062E\u0627\u062F\u0645.",
    privacyStorageTitle: "\u0645\u0627 \u0627\u0644\u0630\u064A \u064A\u062A\u0645 \u062D\u0641\u0638\u0647",
    privacyStorageBody: "\u062A\u064F\u062D\u0641\u0638 \u0645\u062D\u0644\u064A\u0627\u064B \u0641\u0642\u0637 \u062A\u0641\u0636\u064A\u0644\u0627\u062A \u0644\u0648\u062D\u0629 \u0627\u0644\u0645\u0641\u0627\u062A\u064A\u062D \u0648\u0627\u062A\u062C\u0627\u0647 \u0627\u0644\u062A\u062D\u0648\u064A\u0644 \u0648\u0644\u063A\u0629 \u0627\u0644\u0648\u0627\u062C\u0647\u0629. \u0644\u0627 \u062A\u064F\u062D\u0641\u0638 \u0627\u0644\u0646\u0635\u0648\u0635 \u0627\u0644\u0645\u0643\u062A\u0648\u0628\u0629 \u0623\u0648 \u0627\u0644\u0645\u0635\u062D\u062D\u0629.",
    privacyPermissionsTitle: "\u0644\u0645\u0627\u0630\u0627 \u0646\u062D\u062A\u0627\u062C \u0627\u0644\u0635\u0644\u0627\u062D\u064A\u0627\u062A",
    privacyPermissionContext: "\u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0633\u064A\u0627\u0642\u064A\u0629: \u0644\u0625\u0638\u0647\u0627\u0631 KeyFixer \u0639\u0646\u062F \u0627\u0644\u0646\u0642\u0631 \u0628\u0627\u0644\u0632\u0631 \u0627\u0644\u0623\u064A\u0645\u0646 \u0639\u0644\u0649 \u0646\u0635 \u0645\u062D\u062F\u062F.",
    privacyPermissionActive: "\u0627\u0644\u062A\u0628\u0648\u064A\u0628 \u0627\u0644\u0646\u0634\u0637 \u0648\u0627\u0644\u0628\u0631\u0645\u062C\u0629 \u0627\u0644\u0646\u0635\u064A\u0629: \u0644\u0644\u0639\u0645\u0644 \u0639\u0644\u0649 \u0627\u0644\u0635\u0641\u062D\u0629 \u0641\u0642\u0637 \u0628\u0639\u062F \u0627\u062E\u062A\u064A\u0627\u0631\u0643 \u0644\u0623\u0645\u0631 KeyFixer.",
    privacyPermissionStorage: "\u0627\u0644\u062A\u062E\u0632\u064A\u0646: \u0644\u062A\u0630\u0643\u0631 \u062A\u0641\u0636\u064A\u0644\u0627\u062A\u0643 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632.",
    privacyPermissionClipboard: "\u0627\u0644\u062D\u0627\u0641\u0638\u0629: \u0644\u0646\u0633\u062E \u0627\u0644\u0646\u062A\u064A\u062C\u0629 \u0627\u0644\u0645\u0635\u062D\u062D\u0629 \u0639\u0646\u062F\u0645\u0627 \u062A\u0637\u0644\u0628 \u0630\u0644\u0643.",
    privacyNoServices: "\u0644\u0627 \u062A\u062D\u062A\u0648\u064A \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0639\u0644\u0649 \u062A\u062D\u0644\u064A\u0644\u0627\u062A \u0623\u0648 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0623\u0648 \u062D\u0633\u0627\u0628\u0627\u062A \u0623\u0648 \u062E\u062F\u0645\u0627\u062A \u0634\u0628\u0643\u0629 \u0645\u0646 \u0623\u0637\u0631\u0627\u0641 \u062E\u0627\u0631\u062C\u064A\u0629.",
    termsTitle: "\u0634\u0631\u0648\u0637 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645",
    termsUpdated: "\u0622\u062E\u0631 \u062A\u062D\u062F\u064A\u062B: 1 \u0623\u063A\u0633\u0637\u0633 2026",
    termsPurposeTitle: "\u0627\u0644\u063A\u0631\u0636",
    termsPurposeBody: "KeyFixer \u0623\u062F\u0627\u0629 \u0645\u062C\u0627\u0646\u064A\u0629 \u0644\u062A\u0635\u062D\u064A\u062D \u0627\u0644\u0646\u0635 \u0627\u0644\u0645\u0643\u062A\u0648\u0628 \u0628\u062A\u062E\u0637\u064A\u0637 \u0644\u0648\u062D\u0629 \u0645\u0641\u0627\u062A\u064A\u062D \u0639\u0631\u0628\u064A\u0629 \u0623\u0648 \u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D.",
    termsUseTitle: "\u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0645\u0642\u0628\u0648\u0644",
    termsUseBody: "\u064A\u0645\u0643\u0646\u0643 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647\u0627 \u0644\u0623\u0639\u0645\u0627\u0644\u0643 \u0627\u0644\u0634\u062E\u0635\u064A\u0629 \u0623\u0648 \u0627\u0644\u0645\u0647\u0646\u064A\u0629. \u0644\u0627 \u064A\u062C\u0648\u0632 \u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0647\u0627 \u0641\u064A \u0646\u0634\u0627\u0637 \u063A\u064A\u0631 \u0642\u0627\u0646\u0648\u0646\u064A\u060C \u0623\u0648 \u062A\u0642\u062F\u064A\u0645\u0647\u0627 \u0643\u0645\u0646\u062A\u062C\u0643 \u0627\u0644\u062E\u0627\u0635\u060C \u0623\u0648 \u0625\u0633\u0627\u0621\u0629 \u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0633\u0645\u0647\u0627 \u0623\u0648 \u0647\u0648\u064A\u062A\u0647\u0627.",
    termsDisclaimerTitle: "\u0625\u062E\u0644\u0627\u0621 \u0627\u0644\u0645\u0633\u0624\u0648\u0644\u064A\u0629",
    termsDisclaimerBody: "\u062A\u064F\u0642\u062F\u064E\u0651\u0645 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0643\u0645\u0627 \u0647\u064A. \u0631\u0627\u062C\u0639 \u0627\u0644\u0646\u0635 \u0627\u0644\u0645\u0635\u062D\u062D \u0642\u0628\u0644 \u0627\u0644\u0627\u0639\u062A\u0645\u0627\u062F \u0639\u0644\u064A\u0647\u061B \u0644\u0627 \u064A\u0645\u0643\u0646 \u0636\u0645\u0627\u0646 \u0627\u0644\u062A\u0648\u0627\u0641\u0642 \u0648\u062F\u0642\u0629 \u0627\u0644\u062A\u062D\u0648\u064A\u0644 \u0639\u0644\u0649 \u0643\u0644 \u0645\u0648\u0642\u0639 \u0623\u0648 \u0625\u0639\u062F\u0627\u062F.",
    developerTitle: "\u0639\u0646 \u0627\u0644\u0645\u0637\u0648\u0631",
    developerName: "\u0639\u0628\u0627\u062F\u0629 \u062F\u0644\u0644\u0648",
    developerBody: "KeyFixer \u0623\u062F\u0627\u0629 \u0645\u0633\u062A\u0642\u0644\u0629 \u062A\u0631\u0627\u0639\u064A \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629\u060C \u0635\u0645\u0645\u0647\u0627 \u0648\u0637\u0648\u0631\u0647\u0627 \u0639\u0628\u0627\u062F\u0629 \u062F\u0644\u0644\u0648 \u0644\u062C\u0639\u0644 \u0627\u0644\u0643\u062A\u0627\u0628\u0629 \u0628\u0627\u0644\u0639\u0631\u0628\u064A\u0629 \u0648\u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A\u0629 \u0623\u0633\u0631\u0639 \u0648\u0623\u0642\u0644 \u0625\u0632\u0639\u0627\u062C\u0627\u064B.",
    contactDeveloper: "\u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0645\u0637\u0648\u0631",
    externalNote: "\u064A\u0641\u062A\u062D \u0635\u0641\u062D\u0629 \u0627\u0644\u062A\u0648\u0627\u0635\u0644 \u0627\u0644\u0631\u0633\u0645\u064A\u0629 \u0641\u064A \u062A\u0628\u0648\u064A\u0628 \u062C\u062F\u064A\u062F.",
    backLabel: "\u0631\u062C\u0648\u0639"
  }
};
document.addEventListener("DOMContentLoaded", async () => {
  const inputArea = document.getElementById("input-area");
  const outputArea = document.getElementById("output-area");
  const platformSelect = document.getElementById("platform-select");
  const copyBtn = document.getElementById("copy-btn");
  const clearBtn = document.getElementById("clear-btn");
  const languageBtn = document.getElementById("language-btn");
  const backBtn = document.getElementById("back-btn");
  const characterCount = document.getElementById("character-count");
  const version = document.getElementById("extension-version");
  const caption = document.getElementById("view-caption");
  const segments = [...document.querySelectorAll("[data-mode]")];
  const viewLinks = [...document.querySelectorAll("[data-view]")];
  const prefs = await chrome.storage.local.get(["platform", "mode", "uiLanguage"]);
  let mode = isMode(prefs.mode) ? prefs.mode : "auto";
  let currentView = "home";
  let language = isLanguage(prefs.uiLanguage) ? prefs.uiLanguage : chrome.i18n.getUILanguage().toLowerCase().startsWith("ar") ? "ar" : "en";
  if (prefs.platform === "mac" || prefs.platform === "windows") platformSelect.value = prefs.platform;
  version.textContent = `v${chrome.runtime.getManifest().version}`;
  function translate() {
    document.documentElement.lang = language;
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    languageBtn.textContent = language === "ar" ? "EN" : "\u0639\u0631\u0628\u064A";
    languageBtn.setAttribute("aria-label", language === "ar" ? "Switch to English" : "\u0627\u0644\u062A\u0628\u062F\u064A\u0644 \u0625\u0644\u0649 \u0627\u0644\u0639\u0631\u0628\u064A\u0629");
    backBtn.setAttribute("aria-label", messages[language].backLabel);
    document.querySelectorAll("[data-i18n]").forEach((element) => {
      const key = element.dataset.i18n;
      element.textContent = messages[language][key];
    });
    document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
      const key = element.dataset.i18nPlaceholder;
      element.setAttribute("placeholder", messages[language][key]);
    });
    updateCaption();
  }
  function updateCaption() {
    const captionKeys = {
      home: "tagline",
      privacy: "privacyTitle",
      terms: "termsTitle",
      developer: "developerTitle"
    };
    caption.textContent = messages[language][captionKeys[currentView]];
  }
  function showView(view) {
    currentView = view;
    document.querySelectorAll(".view").forEach((element) => {
      const isTarget = element.id === `${view}-view`;
      element.hidden = !isTarget;
      element.classList.toggle("active-view", isTarget);
    });
    backBtn.hidden = view === "home";
    updateCaption();
  }
  function updateModeButtons() {
    segments.forEach((segment) => {
      const active = segment.dataset.mode === mode;
      segment.classList.toggle("is-active", active);
      segment.setAttribute("aria-pressed", String(active));
    });
  }
  function updateOutput() {
    const text = inputArea.value;
    const platform = platformSelect.value;
    const result = convertKeyboardLayout(text, { mode, platform });
    outputArea.value = result.fixedText;
    characterCount.textContent = String([...text].length);
    copyBtn.disabled = !result.fixedText;
    clearBtn.disabled = !text;
    void chrome.storage.local.set({ platform, mode });
  }
  segments.forEach((segment) => segment.addEventListener("click", () => {
    if (!isMode(segment.dataset.mode)) return;
    mode = segment.dataset.mode;
    updateModeButtons();
    updateOutput();
  }));
  inputArea.addEventListener("input", updateOutput);
  platformSelect.addEventListener("change", updateOutput);
  copyBtn.addEventListener("click", async () => {
    if (!outputArea.value) return;
    try {
      await navigator.clipboard.writeText(outputArea.value);
      const label = copyBtn.querySelector("[data-i18n]");
      if (label) label.textContent = messages[language].copiedButton;
      copyBtn.classList.add("is-copied");
      window.setTimeout(() => {
        if (label) label.textContent = messages[language].copyButton;
        copyBtn.classList.remove("is-copied");
      }, 1600);
    } catch (error) {
      console.warn("KeyFixer: Could not copy corrected text.", error);
    }
  });
  clearBtn.addEventListener("click", () => {
    inputArea.value = "";
    updateOutput();
    inputArea.focus();
  });
  languageBtn.addEventListener("click", () => {
    language = language === "ar" ? "en" : "ar";
    void chrome.storage.local.set({ uiLanguage: language });
    translate();
  });
  viewLinks.forEach((link) => link.addEventListener("click", () => showView(link.dataset.view)));
  backBtn.addEventListener("click", () => showView("home"));
  translate();
  updateModeButtons();
  updateOutput();
});
function isMode(value) {
  return value === "auto" || value === "en2ar" || value === "ar2en";
}
function isLanguage(value) {
  return value === "ar" || value === "en";
}
